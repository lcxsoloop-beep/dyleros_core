# Dummy parser
def parse_reply(reply_text):
    if "yes" in reply_text.lower():
        return "positive"
    elif "call later" in reply_text.lower():
        return "call_later"
    else:
        return "ignore"