# Dummy logger
def log_event(event_type, data):
    print(f"Logged {event_type}: {data}")