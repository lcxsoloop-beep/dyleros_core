# DylerOS Core

This is the execution engine for the FSBO estimate machine.

## Setup

1. Rename `.env.template` to `.env` and fill in your API keys
2. Install dependencies: `pip install -r requirements.txt`
3. Run the server: `python3 dyler_api.py`