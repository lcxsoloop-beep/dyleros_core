from flask import Flask, request, jsonify
import subprocess

app = Flask(__name__)

@app.route('/')
def home():
    return "DylerOS API is live"

@app.route('/run_script', methods=['POST'])
def run_script():
    script_name = request.json.get("script")
    try:
        result = subprocess.run(["python3", script_name], capture_output=True, text=True)
        return jsonify({"output": result.stdout, "error": result.stderr})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)