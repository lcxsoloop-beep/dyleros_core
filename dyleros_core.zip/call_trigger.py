# Dummy Vapi trigger
def trigger_call(phone_number):
    print(f"Triggering AI call to {phone_number}")